#include <iostream>

using namespace std;

int fib(int n, int *count)
{
  *count = *count + 1;
  if (n == 0)
    return 0;
  if (n == 1)
    return 1;
  return fib(n - 1, count) + fib(n - 2, count);
}

int DPfib(int n, int MemoArr[], int *count)
{
  *count = *count + 1;
  if (MemoArr[n] != -1)
  {
    return MemoArr[n];
  }
  if (n == 0)
    return 0;
  if (n == 1)
    return 1;
  int sum = DPfib(n - 1, MemoArr, count) + DPfib(n - 2, MemoArr, count);
  MemoArr[n] = sum;
  return sum;
}

int main()
{
  int count = 0;
  cout << fib(20, &count) << endl;
  cout << "Loop nos : " << count << endl;

  // using DP
  int val = 20;
  int DPcount = 0;
  int MemoArr[val + 1];
  for (int i = 0; i < val + 1; i++)
  {
    MemoArr[i] = -1;
  }
  cout << DPfib(val, MemoArr, &DPcount) << endl;
  cout << DPcount << endl;
  return 0;
}